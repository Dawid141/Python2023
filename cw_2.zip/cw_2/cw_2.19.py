L = [7, 24, 123, 45, 6, 789, 100, 3, 2, 1, 14, 21]

numbers = [str(number).zfill(3) for number in L]
print(numbers)
