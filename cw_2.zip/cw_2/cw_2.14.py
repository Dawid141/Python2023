def longest_word(line):
    word = line.split()
    longest = max(word, key=len)
    print(longest)
    print("dlugosc slowa", len(longest))


longest_word("hej heeeeej h")
