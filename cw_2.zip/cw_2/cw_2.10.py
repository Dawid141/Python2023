
def num_words(line):
    words_number = len(line.split())
    print(words_number)

num_words("witam witam  hej         hej")

