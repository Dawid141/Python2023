def lenght_of(line):
    var = line.split()
    word = ""
    for x in var:
        word += x
    print(len(word))


lenght_of("a a a a a    ada")
