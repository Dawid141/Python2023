def insert_(word):
    print("_".join(word))

insert_("python")