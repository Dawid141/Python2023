def num_of_zeros(number):
    x = [int(i) for i in str(number)]
    print(x.count(0))

num_of_zeros(1000000)