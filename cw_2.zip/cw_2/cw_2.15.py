L = [1,2,3,4,5,6,7]

number_merge = ""
for x in L:
    number_merge += str(x)

print(number_merge)
