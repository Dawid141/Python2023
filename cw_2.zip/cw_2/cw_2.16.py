def change_dvr(line):
        word = line.replace("GvR", "Guido van Rossum")
        print(word)

change_dvr("hej hejGvR")
