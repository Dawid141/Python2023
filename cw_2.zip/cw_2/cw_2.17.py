def sort_alphabeticly(line):
    word = sorted(line.split())
    print(word)

def sort_by_longest(line):
    word = line.split()
    word.sort(key=len)
    print(word)

sort_alphabeticly("dale cale bale ale")
sort_by_longest("aaaa aaaaaaaa aa")



