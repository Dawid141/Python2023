def first_words(line):
    var = [words_number[0] for words_number in line.split()]
    word = ""
    for x in var:
        word += x
    print(word)

def last_word(line):
    var = [words_number[-1] for words_number in line.split()]
    word = ""
    for x in var:
        word += x
    print(word)

first_words("na ekranie siedzi wrona")
last_word("na ekranie siedzi wrona")
